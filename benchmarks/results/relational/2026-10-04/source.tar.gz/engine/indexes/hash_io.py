"""PageManager-backed I/O for hash metadata, directory, and bucket pages."""

from __future__ import annotations

from functools import wraps
from threading import RLock

from engine.catalog.types import DataType
from engine.errors import InvalidTypeError, ValidationError
from engine.storage.page import Page
from engine.storage.page_manager import PageManager

from .hash_bucket import HashBucket, HashBucketCodec
from .hash_directory import HashDirectoryCodec, HashDirectoryPage
from .hash_header import HashFileHeader


_HEADER_PAGE_ID = 0
_ONLY_SLOT_ID = 0


def _latched(method):
    @wraps(method)
    def call(self, *args, **kwargs):
        with self._mutex:
            return method(self, *args, **kwargs)

    return call


def _require_manager(manager: object) -> PageManager:
    if not isinstance(manager, PageManager):
        raise InvalidTypeError("manager must be a PageManager")
    return manager


def _frame(page_id: int, payload: bytes) -> Page:
    # Hash pages deliberately reuse the ordinary slotted-page envelope instead
    # of introducing a second physical I/O subsystem.
    page = Page(page_id)
    if page.insert(payload) != _ONLY_SLOT_ID:
        raise ValidationError("Hash page payload must occupy slot 0")
    return page


def _payload(page: Page, label: str) -> bytes:
    if page.slot_count != 1 or page.active_record_count != 1:
        raise ValidationError(f"Invalid {label} page layout")
    if not page.slots[_ONLY_SLOT_ID].is_active:
        raise ValidationError(f"Invalid {label} page slot state")
    return page.read(_ONLY_SLOT_ID)


class HashHeaderPageIO:
    """Read and publish the canonical descriptor in physical page zero."""

    @staticmethod
    def write(manager: PageManager, header: HashFileHeader) -> None:
        checked = _require_manager(manager)
        if not isinstance(header, HashFileHeader):
            raise InvalidTypeError("header must be a HashFileHeader")
        if checked.allocated_page_count != header.index_page_count + 1:
            raise ValidationError("Hash header page count does not match the file")
        checked.write_page(_frame(_HEADER_PAGE_ID, header.serialize()))

    @staticmethod
    def read(manager: PageManager) -> HashFileHeader:
        checked = _require_manager(manager)
        if checked.allocated_page_count == 0:
            raise ValidationError("Hash file has no metadata page")
        header = HashFileHeader.deserialize(
            _payload(checked.read_page(_HEADER_PAGE_ID), "hash metadata")
        )
        if checked.allocated_page_count != header.index_page_count + 1:
            raise ValidationError("Hash header page count does not match the file")
        return header


#: Decoded directory pages / buckets kept per open file (Stage 10 Task 10.2d).
_DECODED_LIMIT = 1024


def _remember(cache: dict, page_id: int, payload: bytes, decoded) -> None:
    if len(cache) >= _DECODED_LIMIT:
        cache.pop(next(iter(cache)))
    cache[page_id] = (payload, decoded)


class HashDirectoryPageIO:
    """Transfer strict directory chunks through the shared page manager.

    Decoded pages are immutable and decoding is a pure function of the page
    payload, so a decoded page is reused while its payload is byte-for-byte
    unchanged. The page itself is still read and validated on every call, so
    I/O counters and corruption detection are unaffected.
    """

    def __init__(self, manager: PageManager, *, counter_lock: RLock | None = None) -> None:
        self._manager = _require_manager(manager)
        self._mutex = RLock() if counter_lock is None else counter_lock
        self._decoded: dict = {}
        # Typed counters complement PageManager's aggregate physical counters.
        self.pages_read = 0
        self.pages_written = 0
        self.pages_allocated = 0

    @_latched
    def allocate_page(self) -> int:
        page_id = self._manager.allocate_page()
        if page_id == _HEADER_PAGE_ID:
            raise ValidationError("Allocate hash metadata page before directory pages")
        self.pages_allocated += 1
        return page_id

    @_latched
    def write_page(self, page_id: int, directory_page: HashDirectoryPage) -> None:
        self._manager.write_page(
            _frame(page_id, HashDirectoryCodec.serialize(directory_page))
        )
        self.pages_written += 1

    @_latched
    def read_page(self, page_id: int) -> HashDirectoryPage:
        if type(page_id) is not int:
            raise InvalidTypeError("directory page_id must be a built-in int")
        if page_id == _HEADER_PAGE_ID:
            raise ValidationError("Hash directory cannot use metadata page 0")
        with self._manager.counter_scope():
            reads_before = self._manager.pages_read
            try:
                physical_page = self._manager.read_page(page_id)
            finally:
                # Include a completed transfer even if its Page frame is bad.
                self.pages_read += self._manager.pages_read - reads_before
        payload = _payload(physical_page, "hash directory")
        cached = self._decoded.get(page_id)
        if cached is not None and cached[0] == payload:
            return cached[1]
        directory_page = HashDirectoryCodec.deserialize(payload)
        _remember(self._decoded, page_id, payload, directory_page)
        return directory_page

    @_latched
    def reset_counters(self) -> None:
        """Reset only the counters owned by this typed I/O adapter."""

        self.pages_read = self.pages_written = self.pages_allocated = 0


class HashBucketPageIO:
    """Transfer bucket models while validating physical/stored page identity.

    Decoded buckets are reused while their page payload is unchanged, exactly
    as directory pages are (Stage 10 Task 10.2d).
    """

    def __init__(
        self, manager: PageManager, key_type: DataType, *,
        counter_lock: RLock | None = None,
    ) -> None:
        self._manager = _require_manager(manager)
        self._mutex = RLock() if counter_lock is None else counter_lock
        if not isinstance(key_type, DataType):
            raise InvalidTypeError("key_type must be a DataType")
        self._key_type = key_type
        self._decoded: dict = {}
        self.pages_read = 0
        self.pages_written = 0
        self.pages_allocated = 0
        # Merge is deferred in format v1, so no bucket is currently freed.
        self.pages_freed = 0

    @_latched
    def allocate_page(self) -> int:
        page_id = self._manager.allocate_page()
        if page_id == _HEADER_PAGE_ID:
            raise ValidationError("Allocate hash metadata page before bucket pages")
        self.pages_allocated += 1
        return page_id

    @_latched
    def write_bucket(self, bucket: HashBucket) -> None:
        if not isinstance(bucket, HashBucket):
            raise InvalidTypeError("bucket must be a HashBucket")
        if bucket.key_type is not self._key_type:
            raise ValidationError("Hash bucket key type differs from its index")
        self._manager.write_page(
            _frame(bucket.page_id, HashBucketCodec.serialize(bucket))
        )
        self.pages_written += 1

    @_latched
    def read_bucket(self, page_id: int) -> HashBucket:
        if type(page_id) is not int:
            raise InvalidTypeError("bucket page_id must be a built-in int")
        if page_id == _HEADER_PAGE_ID:
            raise ValidationError("Hash bucket cannot use metadata page 0")
        with self._manager.counter_scope():
            reads_before = self._manager.pages_read
            try:
                physical_page = self._manager.read_page(page_id)
            finally:
                self.pages_read += self._manager.pages_read - reads_before
        payload = _payload(physical_page, "hash bucket")
        cached = self._decoded.get(page_id)
        if cached is not None and cached[0] == payload:
            bucket = cached[1]
        else:
            bucket = HashBucketCodec.deserialize(self._key_type, payload)
            _remember(self._decoded, page_id, payload, bucket)
        if bucket.page_id != page_id:
            raise ValidationError("Stored hash bucket page_id differs from its location")
        return bucket

    @_latched
    def reset_counters(self) -> None:
        """Reset only the counters owned by this typed I/O adapter."""

        self.pages_read = self.pages_written = self.pages_allocated = 0
        self.pages_freed = 0
